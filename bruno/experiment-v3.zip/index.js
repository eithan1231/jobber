export const handler = (req, res) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (req.type() === "http") {
        return resolve(res.json({ hello: req.type() }));
      }

      return resolve({
        hello: req.type(),
      });
    }, 1000);
  });
};
