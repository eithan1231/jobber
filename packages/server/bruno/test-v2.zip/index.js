import { helper } from "./dependency.js";

export const handler = (payload) => {
  console.log(helper());
  return "I am really just fucking around and finding out. Peace bro";
};
